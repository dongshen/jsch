package net.neoremind.sshxcute.core;

import java.io.File;

public class IOptionName {

	public static String TIMEOUT = "TIMEOUT";
	
	public static String HALT_ON_FAILURE = "HALT_ON_FAILURE";
	
	public static String INTEVAL_TIME_BETWEEN_TASKS = "INTEVAL_TIME_BETWEEN_TASKS";
	
	public static String SSH_PORT_NUMBER = "SSH_PORT_NUMBER";
	
	public static String ERROR_MSG_BUFFER_TEMP_FILE_PATH = "ERROR_MSG_BUFFER_TEMP_FILE_PATH";
	
}
